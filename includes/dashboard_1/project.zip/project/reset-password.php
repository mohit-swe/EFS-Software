<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>MyMedRem</title>
  <link rel="shortcut icon" href="img/mymedrem.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body data-spy="scroll" data-target="#menu">
<nav class="navbar navbar-inverse fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbard">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="#">MyMedRem</a>
</div>
<div class="collapse navbar-collapse" id="navbard">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="index.html"><span class="glyphicon glyphicon-home"></span>Home</a></li>
<li><a href="index.php"> Login</a></li>
</ul>
</div>
</div>
</nav>
<div class="container text-center">
<div class="row">
<div class="col-sm-12">

<h2><u>Confirm Mail </u></h2>
<p style="font-family:century gothic; color:green;font-size:15px;">Type your email! again to receive a message!</p>
<form action="includes/reset-request.inc.php" style="font-family:century gothic;"  method="post">
<input type="text" name="email" style="font-family:century gothic; background:lightgrey;color:black;font-size:20px;border-radius:8px;"  placeholder=" Enter email address">
<br>
<button type="submit" name="reset-request-submit" style="font-family:century gothic; background:black;color:white;font-size:20px;border-radius:8px;">Click me ! </button><br>
<hr>
</form>

<?php
if(isset($_GET["reset"]))
{
	if($_GET["reset"]=="success")
	{
		echo '<p  style="color:green;font-family:century gothic;font-size:12px;" >Please check your mail :)</p>';
		
	}
	
}

?>
</div>
</div>
</div>



</body>
</html>