<?php
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>MyMedRem</title>
  <link rel="shortcut icon" href="../img/mymedrem.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="../style.css">
</head>
<body data-spy="scroll" data-target="#menu">
<nav class="navbar navbar-inverse fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbard">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="#">MyMedRem</a>
</div>
<div class="collapse navbar-collapse" id="navbard">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="../index.html"><span class="glyphicon glyphicon-home"></span>Home</a></li>
</ul>
</div>
</div>
</nav>
<div class="container text-center" id="about">
<div class="row">
<div class="col-sm-12">

<?php
if(isset($_SESSION['userId']))
{  
    echo '<p style="font-family:century gothic;font-size:23px;color:green;" >Hey you are logged in ! </p>';
	echo '<button type="submit"  style="font-family:century gothic; background:black; color:white;font-size:20px;border-radius:8px;">Get Started</button>';
	echo '<form  action="app_embed_here.php" style="font-family:century gothic;" method="post">
<button type="submit" name="logout-submit"style="font-family:century gothic; background:black;color:white;font-size:20px;border-radius:8px;float:right;">LogOut</button><br>
</form>';
	
}

else
{

	echo '<p style="font-family:century gothic;font-size:23px;color:red;" >You are not logged in ! </p>';
	
	
}
?>


</div>
</div>
</div>
<footer class="container-fluid text-center">
<div class="row">



<div class="col-sm-4">
<a id="icon" href="#">MyMedRem</a>
</div>

<div class="col-sm-4">
<h3><u>Contact Us</u></h3>
<p><i class="fa fa-mobile" aria-hidden="true"></i>Phone:789378388383<br>
 <i class="fa fa-envelope" aria-hidden="true"></i>Mail:mohitojhamohit@gmail.com</p>
 <div class="heading-underline"></div>
<h3><u>Social</u></h3>
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-quora"></a>
</div>

<div class="col-sm-4">
<h3><u>Support Us</u></h3>
<a href="#" class="fa fa-paypal"></a>
<a href="#"><i class="fa fa-cc-visa" aria-hidden="true"></i></a>
</div>
</div>
<hr>
<div class="container-fluid text-center" id="copy"><i class="fa fa-copyright" aria-hidden="true"></i>MyMedRem,2019</div>
</footer>
</body>
</html>
