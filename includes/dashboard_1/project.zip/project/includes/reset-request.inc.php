<?php


$userEmail=$_POST["email"];
if(isset($_POST["reset-request-submit"]))
{
	
	
	
	$url="my website link which i would made /forgottenpassword/index.php? ";
	
	
	
	require 'dbh.inc.php';
    

$to=$userEmail;


$subject='<h2  style="color:green;font-family:century gothic;font-size:12px;" >Welcome with greetings</h2>';


$message .=$url;

$headers ="From:MyMedRem<mohitojha607@gmail.com\r\n";
$headers .="To".$userEmail;
$headers .="Content-type:text/html\r\n";
$headers .="Content-type:text/css\r\n";


mail($to,$subject,$message,$header);
header("Location: ../reset-password.php?reset=success");


}


else 
{

	header("Location:../index.php?");
	
}










































	
	


