<?php

$servername="localhost";
$dBUsername="id8565623_mymed";
$dBPassword="123*@gask";
$dBName="id8565623_mymedrem	";


$conn=mysqli_connect($servername,$dBUsername,$dBPassword,$dBName);
if(!$conn)
{
	die("connection");
}